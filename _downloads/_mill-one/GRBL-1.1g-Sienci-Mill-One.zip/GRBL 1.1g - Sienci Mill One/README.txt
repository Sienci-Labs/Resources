Grbl 1.1g for Sienci Mill One
Updated July 3, 2018
If you have any questions, comments, concerns, or want to report a bug, contact us at hi@sienci.com

-------------------------

Uploading firmware:

If this is your first time uploading the firmware to your Mill One's Arduino, you can find instructions here: https://sienci.com/mill-one-resources/firmware/

If you are updating older firmware to the newest firmware, make sure to run "eeprom_clear" first.

You will also need to delete the old GRBL library and reinstall the new one from this folder. You can usually find the "Libraries" folder in the "Documents" directory of your computer.

Uploading new firmware will delete your old machine settings. Make sure to write them down or save them somewhere so that you can change back your settings.

------------------------- 

Gcode senders:

This folder also contains Universal Gcode Sender and UGS Platform. Both are great Gcode senders, and we recommend them. You can use the ones packaged in this folder, or download them online at https://winder.github.io/ugs_website/download/.

