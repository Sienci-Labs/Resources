To start UGSPlatform, go to the "bin" folder -> and choose the .exe program related to your OS and computer architecture (32bit vs 64bit).
