# superlongboard-ext
Hardware repo for the SLB-EXT board for the Altmill.
