80mm Dust Shoe Print Settings:

All print files are scaled and oriented appropriately as is in millimetres for your respective slicer. 

Print using a 4mm nozzle with 0.2mm or finer layer height. Default settings for your slicer should suffice unless otherwise stated. Increasing flow rate tends to help with part strength and quality on lower output extruders.

For the Spindle Body it is recommended to use tree supports around the large overhang towards the back of the part and around the window cutout - try to avoid leaving remnants of supports on the groove where the window is seated. 

All other parts should not require supports for printers where they can successfully print up to a 28 degree overhang angle and with good bridging settings. If supports are required, it is recommended to use tree supports and avoid areas where parts interface with one another.